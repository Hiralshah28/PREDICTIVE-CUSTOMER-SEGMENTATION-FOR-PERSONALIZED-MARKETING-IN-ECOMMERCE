import pandas as pd
from utils.preprocessing import preprocess_data
from utils.eda import run_eda
from utils.model_utils import train_models, evaluate_models, interpret_model, split_data

# Load dataset
df = pd.read_csv("data/shopping_behavior_updated (1).csv")

# Preprocess
X, y = preprocess_data(df)

# EDA (Optional)
run_eda(df)

# Split into train and test
X_train, X_test, y_train, y_test = split_data(X, y)

# Train with GridSearchCV and Save Model
best_model = train_models(X_train, y_train)

# Evaluate on train and test
evaluate_models(best_model, X_train, X_test, y_train, y_test)

# SHAP Interpretability
interpret_model(best_model, X_train)
