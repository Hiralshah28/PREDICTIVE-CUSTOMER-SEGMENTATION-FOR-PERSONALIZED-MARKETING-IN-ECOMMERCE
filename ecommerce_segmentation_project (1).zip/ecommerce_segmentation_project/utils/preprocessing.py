import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE

def preprocess_data(df):
    df = df.copy()

    # Drop IDs / high cardinality
    df.drop(columns=['Customer ID', 'Item Purchased', 'Color'], errors='ignore', inplace=True)

    # Fill missing values
    df['Review Rating'].fillna(df['Review Rating'].median(), inplace=True)
    df['Discount Applied'].fillna(0, inplace=True)
    df['Shipping Type'].fillna(df['Shipping Type'].mode()[0], inplace=True)

    # Encode binary
    for col in ['Gender', 'Subscription Status', 'Promo Code Used', 'Discount Applied']:
        df[col] = df[col].str.lower().map({'yes': 1, 'no': 0, 'female': 1, 'male': 0})

    # One-hot encoding for nominal
    df = pd.get_dummies(df, columns=['Location', 'Category', 'Payment Method', 'Shipping Type', 'Season', 'Size'], drop_first=True)

    # Normalize
    scaler = StandardScaler()
    for col in ['Age', 'Purchase Amount (USD)', 'Review Rating', 'Previous Purchases']:
        df[col] = scaler.fit_transform(df[[col]])

    # Label encode target
    y = df['Frequency of Purchases']
    le = LabelEncoder()
    y = le.fit_transform(y)

    # Drop target from features
    X = df.drop('Frequency of Purchases', axis=1)

    # Handle imbalance with SMOTE
    sm = SMOTE(random_state=42)
    X_res, y_res = sm.fit_resample(X, y)

    return X_res, y_res
