import os
import joblib
import shap
import matplotlib.pyplot as plt

from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from catboost import CatBoostClassifier
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.metrics import classification_report, confusion_matrix, f1_score

def split_data(X, y):
    return train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

def train_models(X_train, y_train):
    print("Running GridSearchCV for Random Forest...")

    rf = RandomForestClassifier(class_weight='balanced', random_state=42)
    param_grid = {
        'n_estimators': [100, 150],
        'max_depth': [10, 20, None],
        'min_samples_split': [2, 5]
    }

    grid = GridSearchCV(rf, param_grid, scoring='f1_macro', cv=3, n_jobs=-1)
    grid.fit(X_train, y_train)
    
    best_model = grid.best_estimator_

    print(f"\n✅ Best RF Params: {grid.best_params_}")
    print(f"✅ Best F1 Score (CV): {grid.best_score_:.4f}")

    # Save model
    os.makedirs("models", exist_ok=True)
    joblib.dump(best_model, "models/best_rf_model.pkl")
    print("✅ Model saved to models/best_rf_model.pkl")

    return best_model

def evaluate_models(model, X_train, X_test, y_train, y_test):
    print("\n=== Training Set Evaluation ===")
    train_preds = model.predict(X_train)
    print(classification_report(y_train, train_preds))
    print("Confusion Matrix:\n", confusion_matrix(y_train, train_preds))

    print("\n=== Test Set Evaluation ===")
    test_preds = model.predict(X_test)
    print(classification_report(y_test, test_preds))
    print("Confusion Matrix:\n", confusion_matrix(y_test, test_preds))

    print("F1 Score (Test):", f1_score(y_test, test_preds, average="macro"))

def interpret_model(model, X):
    import shap
    import matplotlib.pyplot as plt
    import warnings

    try:
        # Ensure float input
        X_numeric = X.copy().astype('float64')

        # Suppress SHAP warnings (e.g., additivity check)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            explainer = shap.Explainer(model, X_numeric[:200])
            shap_values = explainer(X_numeric[:200])

        # Generate summary plot
        shap.summary_plot(shap_values, X_numeric[:200], show=False)
        plt.tight_layout()
        plt.savefig("reports/shap_summary.png")
        print("✅ SHAP plot saved to reports/shap_summary.png")

    except Exception as e:
        print("⚠️ SHAP visualization failed:", e)
