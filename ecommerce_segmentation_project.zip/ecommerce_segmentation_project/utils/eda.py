import matplotlib.pyplot as plt
import seaborn as sns

def run_eda(df):
    plt.figure(figsize=(8, 5))
    sns.countplot(x='Frequency of Purchases', data=df)
    plt.title('Purchase Frequency Distribution')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

    plt.figure(figsize=(10, 5))
    sns.boxplot(x='Frequency of Purchases', y='Purchase Amount (USD)', data=df)
    plt.title('Purchase Amount by Frequency')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

    corr = df[['Purchase Amount (USD)', 'Previous Purchases', 'Review Rating', 'Age']].corr()
    sns.heatmap(corr, annot=True, cmap='coolwarm')
    plt.title("Correlation Matrix")
    plt.show()
