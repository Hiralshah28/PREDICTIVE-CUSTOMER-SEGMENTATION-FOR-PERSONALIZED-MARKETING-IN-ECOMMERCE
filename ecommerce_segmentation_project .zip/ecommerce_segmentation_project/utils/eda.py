import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

def run_eda(df):
    # Age Group Column for grouped plots
    df['Age Group'] = pd.cut(df['Age'], bins=[0, 20, 30, 40, 50, 60, 100],
                             labels=["<20", "20-30", "30-40", "40-50", "50-60", "60+"])
    
    plt.figure(figsize=(8, 5))
    sns.countplot(x='Frequency of Purchases', data=df, palette="Spectral")
    plt.title('Purchase Frequency Distribution')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

    plt.figure(figsize=(10, 5))
    sns.boxplot(x='Frequency of Purchases', y='Purchase Amount (USD)', data=df, palette="Spectral")
    plt.title('Purchase Amount by Frequency')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

    corr = df[['Purchase Amount (USD)', 'Previous Purchases', 'Review Rating', 'Age']].corr()
    sns.heatmap(corr, annot=True, cmap='coolwarm')
    plt.title("Correlation Matrix")
    plt.show()

    # 1. Count Plot: Product Categories Purchased
    plt.figure(figsize=(7, 5))
    sns.countplot(data=df, x="Category", palette="Spectral")
    plt.title("Count Plot of Product Categories Purchased")
    plt.xticks(rotation=15)
    plt.tight_layout()
    plt.savefig("reports/plot_count_categories.png")
    plt.show()

    # 2. Box Plot: Purchase Amount by Category
    plt.figure(figsize=(7, 5))
    sns.boxplot(data=df, x="Category", y="Purchase Amount (USD)", palette="Spectral")
    plt.title("Box Plot of Purchase Amount by Category")
    plt.tight_layout()
    plt.savefig("reports/plot_box_amount_by_category.png")
    plt.show()

    # 3. Subscription Status
    plt.figure(figsize=(6, 4))
    sns.countplot(data=df, x="Subscription Status", palette="autumn")
    plt.title("Subscription Status Class Distribution")
    plt.tight_layout()
    plt.savefig("reports/plot_subscription_status.png")
    plt.show()

    # 4. Payment Method Distribution
    plt.figure(figsize=(8, 5))
    sns.countplot(data=df, x="Payment Method", palette="Set2")
    plt.title("Payment Method Distribution")
    plt.xticks(rotation=15)
    plt.tight_layout()
    plt.savefig("reports/plot_payment_methods.png")
    plt.show()

    # 5. Category-Wise Average Purchase Amount by Gender
    plt.figure(figsize=(7, 5))
    sns.barplot(data=df, x="Category", y="Purchase Amount (USD)", hue="Gender", palette="YlOrBr")
    plt.title("Segment-wise Average Purchase Amount by Category and Gender")
    plt.tight_layout()
    plt.savefig("reports/plot_category_gender_avg_amount.png")
    plt.show()

    # 6. Frequency of Purchases Across Age Groups
    plt.figure(figsize=(10, 5))
    sns.countplot(data=df, x='Age Group', hue='Frequency of Purchases', palette='Set3')
    plt.title("Frequency of Purchases Across Age Groups")
    plt.tight_layout()
    plt.savefig("reports/plot_frequency_by_age_group.png")
    plt.show()

    print("✅ All EDA plots saved in /reports folder")









































# import matplotlib.pyplot as plt
# import seaborn as sns

# def run_eda(df):
#     plt.figure(figsize=(8, 5))
#     sns.countplot(x='Frequency of Purchases', data=df)
#     plt.title('Purchase Frequency Distribution')
#     plt.xticks(rotation=45)
#     plt.tight_layout()
#     plt.show()

#     plt.figure(figsize=(10, 5))
#     sns.boxplot(x='Frequency of Purchases', y='Purchase Amount (USD)', data=df)
#     plt.title('Purchase Amount by Frequency')
#     plt.xticks(rotation=45)
#     plt.tight_layout()
#     plt.show()

#     corr = df[['Purchase Amount (USD)', 'Previous Purchases', 'Review Rating', 'Age']].corr()
#     sns.heatmap(corr, annot=True, cmap='coolwarm')
#     plt.title("Correlation Matrix")
#     plt.show()



    